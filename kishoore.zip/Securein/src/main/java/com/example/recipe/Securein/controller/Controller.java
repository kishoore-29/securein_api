package com.example.recipe.Securein.controller;
import com.example.recipe.Securein.model.Recipe;
import com.example.recipe.Securein.service.Services;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;
@RestController
@RequestMapping("/")
public class Controller {
    @Autowired
    Services service;
    @GetMapping("/")
    public String home(){
        return "Welcome";
    }
    @PostMapping("/recipes")
    public Recipe addRecipe(@Valid @RequestBody Recipe recipe) {
        return service.saveRecipe(recipe);
    }
    @GetMapping("/recipes/top")
    public List<Recipe> getTop(@RequestParam int limit){
        return service.fetch(limit);
    }
    @PostMapping("/upload")
    public ResponseEntity<String> uploadJson(@RequestParam("file") MultipartFile file) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        java.util.Map<String, Recipe> recipeMap = mapper.readValue(
                file.getInputStream(),
                new com.fasterxml.jackson.core.type.TypeReference<>() {
                }
        );
        List<Recipe> recipes = new java.util.ArrayList<>(recipeMap.values());
        service.bulkSave(recipes);
        return ResponseEntity.ok("added: " + recipes.size());
    }
}
