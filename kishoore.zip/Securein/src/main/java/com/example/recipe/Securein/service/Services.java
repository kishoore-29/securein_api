package com.example.recipe.Securein.service;


import com.example.recipe.Securein.model.Recipe;
import com.example.recipe.Securein.repository.Repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import java.util.List;
@Component
@Service
public class Services {
    @Autowired
    Repo repo;
    public Recipe saveRecipe(Recipe recipe){
        return repo.save(recipe);
    }
    public List<Recipe> fetch(int limit) {
        Pageable pageable = PageRequest.of(0, limit, Sort.by(Sort.Direction.DESC, "rating"));
        return repo.findAll(pageable).getContent();
    }
    public void bulkSave(List<Recipe> offices){
        repo.saveAll(offices);
    }
}
