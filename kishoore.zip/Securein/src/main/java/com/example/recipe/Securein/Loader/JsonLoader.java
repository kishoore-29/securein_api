package com.example.recipe.Securein.Loader;

import com.example.recipe.Securein.model.Nutrients;
import com.example.recipe.Securein.model.Recipe;
import com.example.recipe.Securein.service.Services;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Configuration
@RequiredArgsConstructor
public class JsonLoader {
    @Autowired
    Services service;
    @Value("classpath:US_recipes_null.json")
    private Resource recipeResource;

    @Bean
    CommandLineRunner loadData() {
        return args -> {
            if (!service.fetch(1).isEmpty()) {
                return;
            }
            ObjectMapper mapper = new ObjectMapper();
            try (InputStream input = recipeResource.getInputStream()) {
                System.out.println("Parsing 13MB JSON file...");
                JsonNode root = mapper.readTree(input);
                List<Recipe> x = new ArrayList<>();
                root.forEach(node -> {
                    if (node.path("title").isMissingNode() || node.path("title").isNull() ||
                            node.path("cuisine").isMissingNode() || node.path("cuisine").isNull() ||
                            node.path("prep_time").isMissingNode() ||
                            node.path("cook_time").isMissingNode()) {
                        return;
                    }
                    JsonNode nNode = node.get("nutrients");
                    Nutrients nutrients = null;
                    if (nNode != null && !nNode.isNull()) {
                        nutrients = Nutrients.builder()
                                .calories(nNode.path("calories").asText(null))
                                .carbohydrateContent(nNode.path("carbohydrateContent").asText(null))
                                .cholesterolContent(nNode.path("cholesterolContent").asText(null))
                                .fiberContent(nNode.path("fiberContent").asText(null))
                                .proteinContent(nNode.path("proteinContent").asText(null))
                                .saturatedFatContent(nNode.path("saturatedFatContent").asText(null))
                                .sodiumContent(nNode.path("sodiumContent").asText(null))
                                .sugarContent(nNode.path("sugarContent").asText(null))
                                .fatContent(nNode.path("fatContent").asText(null))
                                .unsaturatedFatContent(nNode.path("unsaturatedFatContent").asText(null))
                                .build();
                    }
                    Recipe recipe = Recipe.builder()
                            .title(node.get("title").asText())
                            .cuisine(node.get("cuisine").asText())
                            .rating(node.path("rating").asDouble(0.0))
                            .prepTime(node.get("prep_time").asInt())
                            .cookTime(node.get("cook_time").asInt())
                            .description(node.path("description").asText(null))
                            .serves(node.path("serves").asText(null))
                            .nutrients(nutrients)
                            .build();

                    x.add(recipe);
                });
                service.bulkSave(x);
            } catch (Exception e) {
            }
        };
    }
}