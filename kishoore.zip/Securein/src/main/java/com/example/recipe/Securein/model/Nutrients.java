package com.example.recipe.Securein.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Embeddable;
import lombok.*;
@Embeddable
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Nutrients {
    private String calories;
    private String carbohydrateContent;
    private String cholesterolContent;
    private String fiberContent;
    private String proteinContent;
    private String saturatedFatContent;
    private String sodiumContent;
    private String sugarContent;
    private String fatContent;
    private String unsaturatedFatContent;
}