package com.example.recipe.Securein.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "recipes")
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Builder
public class Recipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Title is mandatory")
    private String title;
    @NotBlank(message = "Cusine is mandatory")
    private String cuisine;
    private Double rating;
    @NotBlank(message = "preparation time is mandatory")
    @JsonProperty("prep_time")
    private Integer prepTime;
    @NotBlank(message = "cooking time is mandatory")
    @JsonProperty("cook_time")
    private Integer cookTime;
    @JsonProperty("total_time")
    private Integer totalTime;
    @Column(columnDefinition = "TEXT")
    private String description;
    @Embedded
    private Nutrients nutrients;
    private String serves;
    public Recipe(Long id, String title, String cuisine,
                  Double rating, Integer prepTime, Integer cookTime, Integer totalTime,
                  String description, Nutrients nutrients, String serves) {
        this.id = id;
        this.title = title;
        this.cuisine = cuisine;
        this.rating = rating;
        this.prepTime = prepTime;
        this.cookTime = cookTime;
        this.totalTime = prepTime+cookTime;
        this.description = description;
        this.nutrients = nutrients;
        this.serves = serves;
    }
    public Recipe(){}
}