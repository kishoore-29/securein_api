package com.example.recipe.Securein;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureinApplicationTests {

	@Test
	void contextLoads() {
	}

}
